import json 

def lambda_handler(event, context):
    """ A simple Lambda function that a GET request from API Gateway. """

    # This is the data you want to return
    response_data = {
        "message": "Hello!, Your GET request was recieved successfully.",
        "status": "success"
    }

    # This is required response formate for API Gateway
    # The 'body' must be a JSON-formatted string, which is why we use json 

    return {
        "statusCode": 200,
        "headers": {
            "Content-Type": "application/json"
        },
        "body": json.dumps(response_data)
    }